%  Global-Local Neighborhood Search Algorithm (GLNSA)
%
%  Source codes version 2.0
%
%  Developed in MATLAB R2015a(7.08)
%
%  Author and programmer: Juan Carlos Seck Tuoh Mora
%
%  email:   jseck@uaeh.edu.mx
%           juanseck@gmail.com
%
%  Main paper:
%  Juan Carlos Seck Tuoh Mora, Nayeli Jazmin Escamilla Serna, Joselito Medina Marin, 
%  Norberto Hernandez Romero, Irving Barragan Vite, Jose Ramon Corona Armenta,
%  A global-local neighborhood search algorithm and tabu search for flexible job shop scheduling problem
%  PeerJ Computer Science, DOI: http://
%_______________________________________________________________________________________________
% The initial parameters that you need are:
%__________________________________________
% smart_number = number of smart_cells
% generation_number = maximum number of iterations
% stagnation_number = maximum number of stagnation iterations
% elitism_prob = propbability of elitist smart_cells
% nieghbor_number = number of neighbors
%______________________________________________________________________________________________

clear all
problem = 'la31.fjs';

%GLNSA Parameters
smart_number = 40;
generation_number = 250;
stagnation_number = 40;
elitism_prob = 0.02;
nieghbor_number = 2;

%Read problem data
[job_number, machine_number, operations_number, operations_number_vector, operations_start_vector, operations_vector, time_table, feasible_machines_table] = readProblemData(problem);

tic;
[so, sm, best_makespan, ~, ~, ~, convergence_curve] = GLNSA(smart_number, generation_number, stagnation_number, elitism_prob, nieghbor_number, job_number, machine_number, operations_number, operations_number_vector, operations_start_vector, operations_vector, time_table, feasible_machines_table);
execution_time=toc;

%Best solution
disp(['Best makespan: ' num2str(best_makespan)])
disp(['Execution time: ' num2str(execution_time)])


machineGanttDiagram(so, sm, job_number, machine_number, operations_number, operations_start_vector, time_table)

figure(2)
plot(1:size(convergence_curve,2),convergence_curve,'linewidth',1.5)
xlim([1,size(convergence_curve,2)])
title('Optimization of LA31 instance','fontsize',16)
xl=xlabel('Iteration','fontsize',14);
xl.Position(2)=xl.Position(2)-.2;
yl=ylabel('Makespan','fontsize',14);
yl.Position(1)=yl.Position(1)-.2;
yticks(1400:100:2800)
grid on

function [job_number, machine_number, operations_number, operations_number_vector, operations_start_vector, operations_vector, time_table, feasible_machines_table] = readProblemData(filename)
% The function reads the problem data table and returns the number of jobs, the number of machines,
% the vector with the number of operations per job, the vector with the
% previous operation number where each job starts, the base vector with repeated operations for each 
% job (1, ..., 1,2, ..., 2, ..., n ... n), the table of times (operations / machines) and the vector 
% of the initial operation number of each job, in which operation number starts from 0

% Data format:
% in the first line there are (at least) 2 numbers: the first is the number of jobs and the second the number
% of machines (the 3rd is not necessary, it is the average number of machines per operation)

% Every row represents one job: the first number is the number of operations of that job, the second number
% (let's say k>=1) is the number of machines that can process the first operation; then according to k, there are
% k pairs of numbers (machine,processing time) that specify which are the machines and the processing times;
% then the data for the second operation and so on...

%   Example: Fisher and Thompson 6x6 instance, alternate name (mt06)
%   6   6   1
%   6   1   3   1   1   1   3   1   2   6   1   4   7   1   6   3   1   5   6
%   6   1   2   8   1   3   5   1   5   10  1   6   10  1   1   10  1   4   4
%   6   1   3   5   1   4   4   1   6   8   1   1   9   1   2   1   1   5   7
%   6   1   2   5   1   1   5   1   3   5   1   4   3   1   5   8   1   6   9
%   6   1   3   9   1   2   3   1   5   5   1   6   4   1   1   3   1   4   1
%   6   1   2   3   1   4   3   1   6   9   1   1   10  1   5   4   1   3   1

% first row = 6 jobs and 6 machines 1 machine per operation
% second row: job 1 has 6 operations, the first operation can be processed by 1 machine that is machine 3 with processing time 1.
% Reference: http://people.idsia.ch/~monaldo/fjsp.html

% Read file
file=fopen(filename,'r');
% Find all integer numeric data that define the problem
data=fscanf(file,'%f');

% Obtain job_number, machine_number
job_number=data(1);
machine_number=data(2);

% Third numerical data is not used

% Initialize operations_vector as empty
operations_vector=[];

% Indices to take jobs, operations and positions in the data array
indice=4;
nt=1;
% Loop to take jobs
while(nt<=job_number)
    % Take number of operations for job nt and put it in the
    % operations_number_vector and vector vectors
    operations_number_vector(nt)=data(indice);
    operations_start_vector(nt)=sum(operations_number_vector(1:nt-1));
    % Add repeated operations for each job to form base solution
    job_operations=ones(1,operations_number_vector(nt))*nt;
    operations_vector=[operations_vector job_operations]; 
    % Lopp to take operations of each job nt
    for operations_number=1:operations_number_vector(nt)
        % Read number of machines feasible to realize the current operation
        indice=indice+1;
        numMaq=data(indice);
        % Loop to take machines and processing times for this operation
        for i=1:numMaq
            % Increase indice, read machine, increase indice, read time
            indice=indice+1;
            machine=data(indice);
            indice=indice+1;
            time=data(indice);
            % Add time in time_table, at row
            % operations_start_vector(nt)+operations_number an column machine
            time_table(operations_start_vector(nt)+operations_number,machine)=time;
        end
    end
    % Take data of the next job
    indice=indice+1;
    nt=nt+1;
end

% Operations number
operations_number=length(operations_vector);
% Fill table of feasible machines for each operation 
feasible_machines_table=[];
% Loop to take operations in time table
for oper=1:length(time_table)
    % Obtain feasible machines for operation oper
    feasible_indices = time_table(oper,:) ~= 0;
    feasible_machines_table=[feasible_machines_table; feasible_indices];
end
end

function [best_so, best_SM, best_makespan, Population_so, Population_SM, Population_makespan, convergence_curve] = GLNSA(smart_number, generation_number, stagnation_number, elitism_prob, nieghbor_number, job_number, machine_number, operations_number, operations_number_vector, operations_start_vector, operations_vector, time_table, feasible_machines_table)
% Implementation of the GLNSA

% Population array, simple to obtain execution speed 
Population_so=zeros(smart_number,operations_number);
Population_SM=zeros(smart_number,operations_number);
Population_makespan=zeros(smart_number,1);
% Table with the features of each solution regarding to jobs,
% ordered by jobs and operations order (J_11, J_12, ... J_nm-1, J_nm)
% Rows keep information in this order: 
% Assigned machine
% Processing position in the assigned machine
% Final time of operation
% Operation length
% Tail time of operation
% Position of the operation in so
% Position of the operation in SM
Population_jobs_table=zeros(6,operations_number,smart_number);

% Table with the features of each solution regarding to machines,
% ordered by machines and operations order (M_11, M_12, ... M_mo-1, M_mo)
% Rows keep information in this order: 
% Programmed job
% Operation of the programmed job 
% Final time of operation
% Operation length
% Tail time of operation
% Position of the operation in so
% Position of the operation in SM
Population_machines_table=zeros(6,operations_number,smart_number);
% Vector with the number of operations assigned to each machine for every solution
Population_machines_vector=zeros(smart_number,machine_number);
Population_machines_order_vector=zeros(smart_number,operations_number);
Population_PosMk=zeros(smart_number,1);
Population_PosTT=zeros(smart_number,operations_number);
Population_PosTM=zeros(smart_number,operations_number);

% Loop to generate initial smart_cells
for i=1:smart_number
    % Generate random smart_cell
    [Population_so(i,:),Population_SM(i,:)] = generateRandomCell(machine_number,operations_number,operations_vector,feasible_machines_table);
end

% Evaluate population
[Population_makespan, Population_PosMk, Population_jobs_table, Population_machines_table, Population_machines_vector, Population_machines_order_vector, Population_PosTT, Population_PosTM] = evaluatePopulation(Population_so, Population_SM, Population_makespan, Population_PosMk, Population_jobs_table, Population_machines_table, Population_machines_vector, Population_machines_order_vector, Population_PosTT, Population_PosTM, job_number, machine_number, operations_number,smart_number,operations_number_vector,operations_start_vector, time_table, 1);
% Select the best of the population
[best_so, best_SM, best_makespan] = bestCell(Population_so, Population_SM, Population_makespan);

% Number of elitist smart_cells
elitist_cell_number=round(smart_number*elitism_prob);
% Updated to get an even number of remaining smart_cells
if mod(smart_number-elitist_cell_number,2)==1
    elitist_cell_number = elitist_cell_number+1;
end

% Iteration counter
contIt=1;
% Stagnation counter
contEst=1;
% Flag for while loop
loop_flag=1;

% Convergence_curve
convergence_curve=[];
convergence_curve(contIt)=best_makespan;
 
% Optimization loop
while(loop_flag)
    % Selection operator for the new population
    [Population_so, Population_SM, Population_makespan,Population_PosMk, Population_jobs_table, Population_machines_table, Population_machines_vector, Population_machines_order_vector, Population_PosTT, Population_PosTM] = selection(Population_so, Population_SM, Population_makespan, Population_PosMk, Population_jobs_table, Population_machines_table, Population_machines_vector, Population_machines_order_vector, Population_PosTT, Population_PosTM, smart_number, elitist_cell_number, 2);
    % Apply neihborhood of GLNSA to each operations_number and obtain improved population
    [Population_so, Population_SM, Population_makespan,Population_PosMk, Population_jobs_table, Population_machines_table, Population_machines_vector, Population_machines_order_vector, Population_PosTT, Population_PosTM] = applyGLNSANeighborhood(Population_so, Population_SM, Population_makespan, Population_PosMk, Population_jobs_table, Population_machines_table, Population_machines_vector, Population_machines_order_vector, Population_PosTT, Population_PosTM, nieghbor_number, smart_number, job_number, machine_number, operations_number, operations_start_vector, time_table, feasible_machines_table, operations_number_vector, elitist_cell_number);
    % Tabu search
    [Population_so, Population_SM, Population_makespan,Population_PosMk, Population_jobs_table, Population_machines_table, Population_machines_vector, Population_machines_order_vector, Population_PosTT, Population_PosTM] = tabuSearchForPopulation(Population_so, Population_SM, Population_makespan, Population_PosMk, Population_jobs_table, Population_machines_table, Population_machines_vector, Population_machines_order_vector, Population_PosTT, Population_PosTM, smart_number, contIt, job_number, machine_number, operations_number, operations_start_vector, time_table, feasible_machines_table, operations_number_vector, elitist_cell_number);
    % Select best operations_number from the new population
    [new_best_so, new_best_SM, new_best_makespan] = bestCell(Population_so, Population_SM, Population_makespan);
    % Check if the previous best operations_number has to be updated
    if new_best_makespan < best_makespan
        best_so = new_best_so;
        best_SM = new_best_SM;
        best_makespan = new_best_makespan;
        contEst=1;
    else
        % On the countrary, increase stagnation counter
        contEst=contEst+1;
    end
    % Check halt condition
    if ((contEst>=stagnation_number) || (contIt>=generation_number))
        loop_flag=0;
    end
    % Display best makespan
    if mod(contIt,20)==0
        disp(['Iteracion: ' num2str(contIt) ' Makespan: ' num2str(best_makespan)]) 
    end
    contIt=contIt+1;
    
    % Update convergence_curve
    convergence_curve(contIt)=best_makespan;
    
end

end

function [so,sm] = generateRandomCell(machine_number,operations_number,operations_vector,feasible_machines_table)
% Input
% operations_vector is the base solution with repetitions
% in feasible_machines_table, each row is the operation in the base order where 
% columns are the machines that can process each operation

% Operations permutation
indices=randperm(operations_number);
so=operations_vector(indices);

% Random assignment of the feasible machines for each operation in the base
% order, following the coding of the HA algorithm
machines_list = 1:machine_number;
sm=zeros(1,operations_number);
for i=1:operations_number
    machines=feasible_machines_table(i,:);
    factibles = machines_list(logical(machines));
    nummachines=length(factibles);
    indmachine=randi([1 nummachines]);
    machine=factibles(indmachine);
    sm(i)=machine;
end

end

function [PobMk, PobPMk, PobTT, PobTM, PobVM, PobVOM, PobPTT, PobPTM] = evaluatePopulation(Pobso, PobSM, PobMk, PobPMk, PobTT, PobTM, PobVM, PobVOM, PobPTT, PobPTM, job_number, machine_number, operations_number,smart_number,operations_number_vector,operations_start_vector, time_table, start)
% Calculate makespan for each operations_number
for i=start:smart_number
    [PobMk(i), PobPMk(i), PobTT(:,:,i), PobTM(:,:,i), PobVM(i,:),PobVOM(i,:), PobPTT(i,:), PobPTM(i,:)] = calculateMakespanTables(Pobso(i,:),PobSM(i,:),job_number, machine_number, operations_number, operations_number_vector,operations_start_vector, time_table, PobTT(:,:,i), PobTM(:,:,i), PobVM(i,:), PobVOM(i,:), PobPTT(i,:), PobPTM(i,:));
end
end

function [makespan,posmk,jobs_table,machines_table,machines_vector,machines_order_vector,posTT,posTM] = calculateMakespanTables(so,sm,job_number, machine_number, operations_number, operations_number_vector,operations_start_vector, time_table, jobs_table, machines_table, machines_vector, machines_order_vector, posTT, posTM)
% Calculate the makespan of a operations_number 
% wit two vectors (operations and machines)

% Initializate makespan
makespan = 0;
posmk = 0;

% current final time of each machine
machine_current_time=zeros(1,machine_number);
% current operation of each job
job_current_op=ones(1,job_number);
% current time of every job
job_current_time=zeros(1,job_number);
% current operation of each machine
machine_current_op=zeros(1,job_number);

% Calculate machines_vector to keep the number of operations in each machine 
for i=1:machine_number
    suma=sum(sm==i);
    machines_vector(i)=suma;
end

for i=1:operations_number
    job=so(i);
    operation=job_current_op(job);
    % Update current operation for the next iteration
    job_current_op(job)=job_current_op(job)+1;
    % operation machine
    position=operations_start_vector(job)+operation;
    machine=sm(position);
    % Update number of operations in the machine
    machine_current_op(machine)=machine_current_op(machine)+1;
    operationmachine=machine_current_op(machine);
    % processing time
    time=time_table(position,machine);
    % Obtain initial time to start the operation
    initial_time=job_current_time(job);
    aux=machine_current_time(machine);
    if aux > initial_time
        initial_time=aux;
    end
    % Schedule operation in machine and job
    machine_current_time(machine)=initial_time+time;
    job_current_time(job)=initial_time+time;
    % Update makespan
    if makespan < initial_time+time
        makespan = initial_time+time;
        posmk = i;
    end
    % Fill jobs_table
    jobs_table(1,position) = machine; % machine assigned to the operation
    jobs_table(2,position) = operationmachine; % position of the operation in the machine
    jobs_table(3,position) = time; % operation length
    jobs_table(4,position) = initial_time+time; % final time of the operation
    jobs_table(5,position) = 0; % tail time of the operation
    jobs_table(6,position) = i; % position of the operation in so
    % Fill machines_table
    positionmachine=sum(machines_vector(1:machine-1))+operationmachine;
    machines_table(1,positionmachine) = job; % job assigned to the machine
    machines_table(2,positionmachine) = operation; % operation of the job
    machines_table(3,positionmachine) = time; % operation length
    machines_table(4,positionmachine) = initial_time+time; % final time of the operation
    machines_table(5,positionmachine) = 0; % tail time of the operation
    machines_table(6,positionmachine) = i; % position of the operation in so
    % Fill machines_order_vector
    machines_order_vector(i) = machine;
    % Fill posTT
    posTT(i)=position;
    % Fill posTM
    posTM(i)=positionmachine;
end

% Calculate tal time
for i=operations_number:-1:1
    postt=posTT(i);
    postm=posTM(i);
    maq=jobs_table(1,postt);
    posm=jobs_table(2,postt);
    trab=machines_table(1,postm);
    oper=machines_table(2,postm);
    if oper == operations_number_vector(trab)
        time_t=0;
    else
        time_t=jobs_table(5,postt+1)+jobs_table(3,postt+1);
    end
    if posm==machines_vector(maq)
        time_m=0;
    else
        time_m=machines_table(5,postm+1)+machines_table(3,postm+1);
    end
    time_cola=max([time_t time_m]);
    jobs_table(5,postt)=time_cola;
    machines_table(5,postm)=time_cola;
end
end

function [best_so, best_SM, mejorMk, indice] = bestCell(Pobso, PobSM, PobMk)
% operations_number with the minimum makespan in the population
[mejorMk, indice] = min(PobMk);
best_so=Pobso(indice,:);
best_SM=PobSM(indice,:);
end

function [new_Pobso, new_PobSM, new_PobMk, new_PobPosMk, new_Pobjobs_table, new_Pobmachines_table, new_Pobmachines_vector, new_Pobmachines_order_vector, new_PobPosTT, new_PobPosTM] = selection(Pobso, PobSM, PobMk, PobPosMk, Pobjobs_table, Pobmachines_table, Pobmachines_vector, Pobmachines_order_vector, PobPosTT, PobPosTM, smart_number, elitism_number, contender_number)
% Complete selection with elitism and tournament
[new_Pobso, new_PobSM, new_PobMk, new_PobPosMk, new_Pobjobs_table, new_Pobmachines_table, new_Pobmachines_vector, new_Pobmachines_order_vector, new_PobPosTT, new_PobPosTM] = elitistSelection(Pobso, PobSM, PobMk, PobPosMk, Pobjobs_table, Pobmachines_table, Pobmachines_vector, Pobmachines_order_vector, PobPosTT, PobPosTM, elitism_number);
ind=elitism_number+1;
while (ind<=smart_number)
    winner_indice = tournamentSelection(PobMk, smart_number, contender_number);
    new_Pobso(ind,:)=Pobso(winner_indice,:);
    new_PobSM(ind,:)=PobSM(winner_indice,:);
    new_PobMk(ind)=PobMk(winner_indice);
    new_PobPosMk(ind)=PobPosMk(winner_indice);
    new_Pobjobs_table(:,:,ind)=Pobjobs_table(:,:,winner_indice);
    new_Pobmachines_table(:,:,ind)=Pobmachines_table(:,:,winner_indice);
    new_Pobmachines_vector(ind,:)=Pobmachines_vector(winner_indice,:);
    new_Pobmachines_order_vector(ind,:)=Pobmachines_order_vector(winner_indice,:);
    new_PobPosTT(ind,:)=PobPosTT(winner_indice,:);
    new_PobPosTM(ind,:)=PobPosTM(winner_indice,:);
    ind=ind+1;
end

end

function [new_Pobso, new_PobSM, new_PobMk, new_PobPosMk, new_Pobjobs_table, new_Pobmachines_table, new_Pobmachines_vector, new_Pobmachines_order_vector, new_PobPosTT, new_PobPosTM] = elitistSelection(Pobso, PobSM, PobMk, PobPosMk, Pobjobs_table, Pobmachines_table, Pobmachines_vector, Pobmachines_order_vector, PobPosTT, PobPosTM, elitism_number)
% Elitist selection of smart_cells in the population 
new_Pobso=Pobso;
new_PobSM=PobSM;
new_PobMk=PobMk;
new_PobPosMk=PobPosMk;
new_Pobjobs_table=Pobjobs_table;
new_Pobmachines_table=Pobmachines_table;
new_Pobmachines_vector=Pobmachines_vector;
new_Pobmachines_order_vector=Pobmachines_order_vector; 
new_PobPosTT=PobPosTT;
new_PobPosTM=PobPosTM;
[ ~, indices ] = sort( PobMk);
for i=1:elitism_number
    new_Pobso(i,:)=Pobso(indices(i),:);
    new_PobSM(i,:)=PobSM(indices(i),:);
    new_PobMk(i)=PobMk(indices(i));
    new_PobPosMk(i)=PobPosMk(indices(i));
    new_Pobjobs_table(:,:,i)=Pobjobs_table(:,:,indices(i));
    new_Pobmachines_table(:,:,i)=Pobmachines_table(:,:,indices(i));
    new_Pobmachines_vector(i,:)=Pobmachines_vector(indices(i),:);
    new_Pobmachines_order_vector(i,:)=Pobmachines_order_vector(indices(i),:);
    new_PobPosTT(i,:)=PobPosTT(indices(i),:);
    new_PobPosTM(i,:)=PobPosTM(indices(i),:);
end
end

function winner_indice= tournamentSelection(PobMk,smart_number,contender_number)
% Select the winner by tournament between random contender_number smart_cells
indices=randperm(smart_number,contender_number);
[~,ind]=min(PobMk(indices));
winner_indice=indices(ind);
end

function [Population_so, Population_SM, Population_makespan,Population_PosMk, Population_jobs_table, Population_machines_table, Population_machines_vector, Population_machines_order_vector, Population_PosTT, Population_PosTM] = applyGLNSANeighborhood(Population_so, Population_SM, Population_makespan, Population_PosMk, Population_jobs_table, Population_machines_table, Population_machines_vector, Population_machines_order_vector, Population_PosTT, Population_PosTM, nieghbor_number, smart_number, job_number, machine_number, operations_number, operations_start_vector, time_table, feasible_machines_table, operations_number_vector, start)
for i=start+1:smart_number
    so=Population_so(i,:);
    sm=Population_SM(i,:);
    jobs_table=Population_jobs_table(:,:,i);
    machines_table=Population_machines_table(:,:,i);
    machines_vector=Population_machines_vector(i,:);
    machines_order_vector=Population_machines_order_vector(i,:);
    posTT=Population_PosTT(i,:);
    posTM=Population_PosTM(i,:);
    [best_so, best_sm, best_mk, best_posmk, best_jobs_table, best_machines_table, best_machines_vector, best_machines_order_vector, best_posTT, best_posTM] = GLNSANeighborhood(so, sm, nieghbor_number, Population_so, smart_number, job_number, machine_number, operations_number, operations_start_vector, time_table, feasible_machines_table, operations_number_vector,jobs_table, machines_table, machines_vector, machines_order_vector, posTT, posTM);
    Population_so(i,:)=best_so;
    Population_SM(i,:)=best_sm;
    Population_makespan(i)=best_mk;
    Population_PosMk(i)=best_posmk; 
    Population_jobs_table(:,:,i)=best_jobs_table; 
    Population_machines_table(:,:,i)=best_machines_table; 
    Population_machines_vector(i,:)=best_machines_vector; 
    Population_machines_order_vector(i,:)=best_machines_order_vector; 
    Population_PosTT(i,:)=best_posTT; 
    Population_PosTM(i,:)=best_posTM;
end
end

function [best_so, best_sm, best_mk, best_posmk, best_jobs_table, best_machines_table, best_machines_vector, best_machines_order_vector, best_posTT, best_posTM ] = GLNSANeighborhood(so, sm, nieghbor_number, Population_so, smart_number, job_number, machine_number, operations_number, operations_start_vector, time_table, feasible_machines_table, operations_number_vector,jobs_table, machines_table, machines_vector, machines_order_vector, posTT, posTM)
% Obtain the best neighbor of one smart_cell using diferent operators 

best_mk=inf;

% Loop to calculate neighborhood
for i=1:nieghbor_number    
    option=rand;
    if option <= 0.5
        [new_so, new_sm, new_mk, new_posmk, new_jobs_table, new_machines_table, new_machines_vector, new_machines_order_vector, new_posTT, new_posTM ] = classicInsertion(so, sm, job_number, machine_number, operations_number,operations_start_vector, time_table, feasible_machines_table,operations_number_vector,jobs_table, machines_table, machines_vector, machines_order_vector, posTT, posTM);
    elseif option > 0.5 && option <= 0.75  
        [new_so, new_sm, new_mk, new_posmk, new_jobs_table, new_machines_table, new_machines_vector, new_machines_order_vector, new_posTT, new_posTM ] = classicSwapping(so, sm, job_number, machine_number, operations_number, operations_start_vector, time_table, feasible_machines_table,operations_number_vector,jobs_table, machines_table, machines_vector, machines_order_vector, posTT, posTM);
    else
        ind=randi(smart_number);
        sof=Population_so(ind,:);
        [new_so, new_sm, new_mk, new_posmk, new_jobs_table, new_machines_table, new_machines_vector, new_machines_order_vector, new_posTT, new_posTM] = classicPathRelinking(so, sm, sof, job_number, machine_number, operations_number, operations_start_vector, time_table,feasible_machines_table,operations_number_vector,jobs_table, machines_table, machines_vector, machines_order_vector, posTT, posTM);
    end
    % Select best neighbor
    if new_mk < best_mk
        best_so=new_so;
        best_sm=new_sm;
        best_mk=new_mk;
        best_posmk=new_posmk;
        best_jobs_table=new_jobs_table; 
        best_machines_table=new_machines_table; 
        best_machines_vector=new_machines_vector; 
        best_machines_order_vector=new_machines_order_vector; 
        best_posTT=new_posTT; 
        best_posTM=new_posTM;
    end
end

end

function [new_so, new_sm, new_mk, new_posmk, new_jobs_table, new_machines_table, new_machines_vector, new_machines_order_vector, new_posTT, new_posTM] = classicPathRelinking(so, sm, sof, job_number, machine_number, operations_number, operations_start_vector, time_table,feasible_machines_table,operations_number_vector,jobs_table, machines_table, machines_vector, machines_order_vector, posTT, posTM)
% Calculate the path relinking moving one operation selected at random

% Select random operation 
position_PR=randi(operations_number-4);
sequence1=sof;
sequence2=so;
final_sequence = pathRelinkingso(sequence1,sequence2,operations_number,position_PR);
new_so=final_sequence;
% Machines mutation
new_sm=sm;
if rand<=0.1
    [new_sm] = machinesMutation(machine_number,operations_number,sm,feasible_machines_table);
end
% Calculate makespan of new samrt-cell
[new_mk,new_posmk,new_jobs_table,new_machines_table,new_machines_vector,new_machines_order_vector,new_posTT,new_posTM] = calculateMakespanTables(new_so,new_sm,job_number, machine_number, operations_number, operations_number_vector,operations_start_vector, time_table, jobs_table, machines_table, machines_vector, machines_order_vector, posTT, posTM);


end

function final_sequence = pathRelinkingso(sequence1,sequence2,secuence_length,position)
% Calculate the path relinking from sequence1 to sequence2 until position
final_sequence=sequence1;
for i=1:position
    operation=sequence2(i);
    if final_sequence(i)~=operation
        % Seek element equal to operation
        j=i+1;
        if j>=secuence_length
            break
        end
        while(1)
            if final_sequence(j)==operation
                % Interchange and break
                final_sequence(j)=final_sequence(i);
                final_sequence(i)=operation;
                break
            end
            j=j+1;
            if j>=secuence_length
                break
            end
        end
    end
end

end

function [new_so, new_sm, new_mk, new_posmk, new_jobs_table, new_machines_table, new_machines_vector, new_machines_order_vector, new_posTT, new_posTM] = classicInsertion(so, sm, job_number, machine_number, operations_number,operations_start_vector, time_table, feasible_machines_table,operations_number_vector,jobs_table, machines_table, machines_vector, machines_order_vector, posTT, posTM)
% Calculate a classic operation insertion
new_so=so;
new_sm=sm;
operation=randi(operations_number);
% Select the position of insertion different from the position of the same job
ind=randi(operations_number);
while(ind==operation)
    ind=randi(operations_number);
end
% Make insertion in new smart_cell 
% operations
new_so(ind)=so(operation);
if operation>ind
    new_so(ind+1:operation)=so(ind:operation-1);
else
    new_so(operation:ind-1)=so(operation+1:ind);
end
% machine mutation
if rand<=0.1
    [new_sm] = machinesMutation(machine_number, operations_number,sm,feasible_machines_table);
end
% Calculate makespan of new smart_cell
[new_mk,new_posmk,new_jobs_table,new_machines_table,new_machines_vector,new_machines_order_vector,new_posTT,new_posTM] = calculateMakespanTables(new_so,new_sm,job_number, machine_number, operations_number, operations_number_vector,operations_start_vector, time_table, jobs_table, machines_table, machines_vector, machines_order_vector, posTT, posTM);
end

function [new_so, new_sm, new_mk, new_posmk, new_jobs_table, new_machines_table, new_machines_vector, new_machines_order_vector, new_posTT, new_posTM] = classicSwapping(so, sm, job_number, machine_number, operations_number, operations_start_vector, time_table, feasible_machines_table,operations_number_vector,jobs_table, machines_table, machines_vector, machines_order_vector, posTT, posTM)
% Calculate n classic swappings of two operations in the operation sequence 
% For the machines, mutation is applied
new_so=so;
new_sm=sm;
for i=1:8
    % Select random operation aleatoria
    ind=randi(operations_number);
    operation=new_so(ind);
    % Select swapping position
    ind2=randi(operations_number);
    operation2=new_so(ind2);
    while(operation2==operation)
        ind2=randi(operations_number);
        operation2=new_so(ind2);
    end
    % Swapping
    new_so(ind)=operation2;
    new_so(ind2)=operation;
end
% machine mutation
if rand<=0.1
    [new_sm] = machinesMutation(machine_number, operations_number,sm,feasible_machines_table);
end
% Calculate makespan of new smart_cell
[new_mk,new_posmk,new_jobs_table,new_machines_table,new_machines_vector,new_machines_order_vector,new_posTT,new_posTM] = calculateMakespanTables(new_so,new_sm,job_number, machine_number, operations_number, operations_number_vector,operations_start_vector, time_table, jobs_table, machines_table, machines_vector, machines_order_vector, posTT, posTM);
end

function [new_smart] = machinesMutation(machine_number, operations_number,smart_cell,feasible_machines_table)
% Machine mutation
% We select half of the positions at random
% For each position, a new feasible machine is selected at random
new_smart = smart_cell;
machines_list = 1:machine_number;
%Indices of the operations to modify
indices=randperm(operations_number,floor(operations_number/2));
for i=1:length(indices)
    machines=feasible_machines_table(indices(i),:);
    factibles = machines_list(logical(machines));
    nummachines=length(factibles);
    indmachine=randi([1 nummachines]);
    maq=factibles(indmachine);
    new_smart(indices(i))=maq;
end

end

function [Pobso, PobSM, PobMk, PobPMk, PobTT, PobTM, PobVM, PobVOM, PobPTT, PobPTM] = tabuSearchForPopulation(Pobso, PobSM, PobMk, PobPMk, PobTT, PobTM, PobVM, PobVOM, PobPTT, PobPTM, smart_number, tabu_iterations, job_number, machine_number, operations_number,operations_start_vector, time_table, feasible_machines_table, operations_number_vector, start)
% Calculate the tabu search and return the improved population
for i=start+1:smart_number
    [Pobso(i,:), PobSM(i,:), PobMk(i), PobPMk(i), PobTT(:,:,i), PobTM(:,:,i), PobVM(i,:), PobVOM(i,:), PobPTT(i,:), PobPTM(i,:)] = tabuSearch(Pobso(i,:), PobSM(i,:), PobMk(i), PobPMk(i), PobTT(:,:,i), PobTM(:,:,i), PobVM(i,:), PobVOM(i,:), PobPTT(i,:), PobPTM(i,:), tabu_iterations, job_number, machine_number, operations_number,operations_start_vector, time_table, feasible_machines_table, operations_number_vector);
end

end

function [best_smart_cellso, best_smart_cellSM, best_smart_cellMk, best_smart_cellPMk, best_smart_cellTT, best_smart_cellTM, best_smart_cellVM, best_smart_cellVOM, best_smart_cellPTT, best_smart_cellPTM] = tabuSearch(smart_cellso, smart_cellSM, smart_cellMk, smart_cellPMk, smart_cellTT, smart_cellTM, smart_cellVM, smart_cellVOM, smart_cellPTT, smart_cellPTM, tabu_iterations, job_number, machine_number, operations_number,operations_start_vector, time_table, feasible_machines_table, operations_number_vector)
% Initialize tabu list
tabu_table=zeros(operations_number,machine_number);
best_smart_cellso = smart_cellso;
best_smart_cellSM = smart_cellSM;
best_smart_cellMk = smart_cellMk;
best_smart_cellPMk = smart_cellPMk;
best_smart_cellTT = smart_cellTT;
best_smart_cellTM = smart_cellTM;
best_smart_cellVM = smart_cellVM;
best_smart_cellVOM = smart_cellVOM;
best_smart_cellPTT = smart_cellPTT;
best_smart_cellPTM = smart_cellPTM;

% Calculate critical path for the current smart_cell
iteration_number = floor(tabu_iterations/2);
iteration=1;
while(iteration<=iteration_number)
    [flag, best_so, best_sm, best_opOrd, best_machine, best_maqf_number, nOpC] = tabuSearchNeighbor(smart_cellso, smart_cellSM, smart_cellMk, smart_cellPMk, smart_cellTT, smart_cellTM, smart_cellVM, smart_cellVOM, smart_cellPTT, smart_cellPTM, job_number, machine_number, operations_number, operations_start_vector, time_table, feasible_machines_table, iteration, tabu_table, operations_number_vector);
    [best_mk,best_pmk,best_TT,best_TM,best_vm,best_vom,best_ptt,best_ptm] = calculateMakespanTables(best_so,best_sm,job_number, machine_number, operations_number, operations_number_vector,operations_start_vector, time_table, smart_cellTT,smart_cellTM,smart_cellVM,smart_cellVOM,smart_cellPTT,smart_cellPTM);
    if flag==0
        % If there is no improved smart-cell and a tabu smart-cell cannot
        % be selected, break the loop
        break
    end
    % Update tabu table
    tabu_table(best_opOrd,best_machine)=iteration+nOpC+best_maqf_number;
    % If the new makespan is better than the current one, replace smart_cell
    if flag==3
        best_smart_cellso=best_so;
        best_smart_cellSM=best_sm;
        best_smart_cellMk=best_mk;
        best_smart_cellPMk = best_pmk;
        best_smart_cellTT = best_TT;
        best_smart_cellTM = best_TM;
        best_smart_cellVM = best_vm;
        best_smart_cellVOM = best_vom;
        best_smart_cellPTT = best_ptt;
        best_smart_cellPTM = best_ptm;
    end
    % New smart_cell for neighborhood 
    iteration = iteration+1;
    smart_cellso = best_so;
    smart_cellSM = best_sm;
    smart_cellMk = best_mk;
    smart_cellPMk = best_pmk;
    smart_cellTT = best_TT;
    smart_cellTM = best_TM;
    smart_cellVM = best_vm;
    smart_cellVOM = best_vom;
    smart_cellPTT = best_ptt;
    smart_cellPTM = best_ptm;
end
end

function [flag, best_so, best_sm, best_opOrd, best_machine, best_maqf_number, nOpC] = tabuSearchNeighbor(smart_cellso, smart_cellSM, smart_cellMk, smart_cellPMk, smart_cellTT, smart_cellTM, smart_cellVM, smart_cellVOM, smart_cellPTT, smart_cellPTM, job_number, machine_number, operations_number, operations_start_vector, time_table, feasible_machines_table, iteracion, tabu_table, operations_number_vector)
% Simplified Nopt1
% A neighbor is calculated selecting nOpC critical operations and changing
% their machines by other feasible ones (if exist)

% Initailize returning solution
best_so = smart_cellso; 
best_sm = smart_cellSM;
best_mk = smart_cellMk;

flag=0; %0.- no new solution. 1.- tabu solution. 2.- non-tabu solution. 3.- improved solution
age=inf;

% Critical path
[RC, machinesRC, tamRC] = criticalPath(operations_number, smart_cellTT, smart_cellTM, smart_cellPTT, smart_cellPTM, smart_cellMk, smart_cellPMk);
nOpC = tamRC;
indSMRC = RC(nOpC:-1:1);
maqRC = machinesRC(nOpC:-1:1);
% random positions in RC
% Keep consecutive operations and corresponding machines
positionsMaq=indSMRC;
machines=maqRC;

% different feasible machines for the
% two selected operations
machines_list = 1:machine_number;

% Loop to take critical operations
for i=1:nOpC
    opOrd=indSMRC(i);
    indMaqFac = feasible_machines_table(positionsMaq(i),:);
    indMaqFac(machines(i))=false;
    factibles = machines_list(logical(indMaqFac));
    numfac = length(factibles);
    for j=1:numfac
        soAux=smart_cellso;
        smAux=smart_cellSM;
        new_machine=factibles(j);
        smAux(positionsMaq(i))=new_machine;                
        pos_os = smart_cellTT(6,opOrd);
        job = soAux(pos_os);
        [new_makespan] = makespanEstimation(pos_os,job,new_machine,operations_number_vector,time_table,smart_cellTT,smart_cellTM,smart_cellPTT,smart_cellPTM,smart_cellVM,smart_cellVOM);
        if (new_makespan < best_mk)
            % Improved solution, update smart_cell a set flag = 3
            best_so=soAux;
            best_sm=smAux;
            best_mk=new_makespan;
            best_opOrd=opOrd;
            best_machine=new_machine;
            best_maqf_number=numfac+1;
            flag=3;
        end
        if (flag~=3) && (tabu_table(opOrd,new_machine)<iteracion) 
            % New solution does not improve smart_cell but it is not tabu,
            % keep the best non-tabu solution
            if (flag~=2) || (new_makespan<new_mk)
                new_so=soAux;
                new_sm=smAux;
                new_mk=new_makespan;
                new_opOrd=opOrd;
                new_numero_maqf=numfac+1;
                flag=2;
            end
        end
        if (flag<=1) && (tabu_table(opOrd,new_machine)>=iteracion) 
            % Tabu solution and another best or non-tabu solution has not
            % been found, keep the oldest tabu solution
            if (flag~=1) || (tabu_table(opOrd,new_machine)<age) 
                new_so=soAux;
                new_sm=smAux;
                new_mk=new_makespan;
                new_opOrd=opOrd;
                new_numero_maqf=numfac+1;
                age=tabu_table(opOrd,new_machine);
                flag=1;
            end
        end
    end
end
                    
% If a tabu or non-tabu solution was found, replace the best solution
if (flag>0) && (flag<3)
    best_so=new_so;
    best_sm=new_sm;
    best_opOrd=new_opOrd;
    best_machine=new_machine;
    best_maqf_number=new_numero_maqf;
end

end

function [RC, maqRC, tamRC] = criticalPath(operations_number, TableTT, TableTM, PosTT, PosTM, Mk, PosMk)
% Calculate critical path
RC=zeros(1,operations_number);
maqRC=zeros(1,operations_number);
tamRC=0;
time_i = Mk;
ind = PosMk;
while(time_i > 0)
    pos_t = PosTT(ind);
    pos_m = PosTM(ind);
    time_i = time_i - TableTT(3,pos_t);
    tamRC = tamRC+1;
    RC(tamRC) = pos_t;
    maqRC(tamRC) = TableTT(1,pos_t);
    if time_i > 0
        if pos_t > 1
            if TableTT(4,pos_t-1)==time_i
                ind = TableTT(6,pos_t-1);
            else
                ind = TableTM(6,pos_m-1);
            end
        else
            ind = TableTM(6,pos_m-1);
        end
    end
end
end

function [new_makespan] = makespanEstimation(pos_os,job,new_maq,operations_number_vector,time_table,smart_cellTT,smart_cellTM,smart_cellPTT,smart_cellPTM,smart_cellVM,smart_cellVOM)
    % Number of previous operations in the new machine
    ind_m=sum(smart_cellVOM(1:pos_os-1)==new_maq);
    ind_TM = sum(smart_cellVM(1:new_maq-1));
    % Calculate final time of the preceding operation in the new machine
    if ind_m == 0
        tf_ma = 0;
    else
        ind_TM = ind_TM + ind_m;
        tf_ma = smart_cellTM(4,ind_TM);
    end
    % Number of preceding operations in the job
    ind_o = smart_cellTM(2,smart_cellPTM(pos_os));
    ind_TT = smart_cellPTT(pos_os);
    % Calculate final time final of the preceding operation in the job
    if ind_o == 1
        tf_oa = 0;
    else
        tf_oa = smart_cellTT(4,ind_TT-1);
    end
    % Maximum final time of the preceding operations
    max_tf_a = max([tf_ma, tf_oa]);
    % Length of the operation in the new machine
    time_length = time_table(ind_TT,new_maq);
    
    % Length of the next operation in the new machine
    % Case if there are not following operations
    if ind_m == smart_cellVM(new_maq)
        tc_ms = 0;
    % There are following operations, take the length of the 
    % next operation plus its tail time
    else
        length_ms = smart_cellTM(3,ind_TM+1);
        tc_ms = length_ms + smart_cellTM(5,ind_TM+1);
    end
    % Length of the next operation in the job
    % Case if there are not following operations
    if ind_o == operations_number_vector(job)
        tc_os = 0;
    % There are following operations, take the length of the 
    % next operation plus its tail time 
    else
        duracion_os = smart_cellTT(3,ind_TT+1);
        tc_os = duracion_os + smart_cellTT(5,ind_TT+1);
    end
    % Maximum final time of the next operation
    max_tf_s = max([tc_ms, tc_os]);
    % Estimated makespan
    new_makespan = max_tf_a + time_length + max_tf_s;
end


function machineGanttDiagram(so, sm, job_number, machine_number, operations_number, operations_start_vector, time_table)
% Use the makespan calculation to calculate and display the Gantt diagram
timesInMaq=zeros(machine_number,job_number*2);
timesFinMaq=zeros(machine_number,job_number*2);
trabMaq=zeros(machine_number,job_number*2);
operTrabMaq=zeros(machine_number,job_number*2);
% Calculate makespan
makespan = 0;
machine_current_time=zeros(1,machine_number);
machine_current_op=zeros(1,machine_number);
job_current_time=zeros(1,job_number);
job_current_op=zeros(1,job_number);
for i=1:operations_number
    trabajo=so(i);
    job_current_op(trabajo)=job_current_op(trabajo)+1;
    operation=job_current_op(trabajo);
    position=operations_start_vector(trabajo)+operation;
    machine=sm(position);
    time=time_table(position,machine);
    timeInicial=job_current_time(trabajo);
    aux=machine_current_time(machine);
    if aux > timeInicial
        timeInicial=aux;
    end
    machine_current_time(machine)=timeInicial+time;
    job_current_time(trabajo)=timeInicial+time;
    machine_current_op(machine)=machine_current_op(machine)+1;
    if makespan < timeInicial+time
        makespan = timeInicial+time;
    end
    % Fill tables for Gantt diagram
    timesInMaq(machine,machine_current_op(machine))=timeInicial;
    timesFinMaq(machine,machine_current_op(machine))=timeInicial+time;
    trabMaq(machine,machine_current_op(machine))=trabajo;
    operTrabMaq(machine,machine_current_op(machine))=job_current_op(trabajo);
end
% Diagram colors
colorT=colormap(hsv(job_number));
colorM=colormap(lines(machine_number));
% Plot de diagram
figure(1);
clf
grid on
grid minor
% Take each machine
for machine=1:machine_number
    y=[machine-0.75 machine-0.25 machine-0.25 machine-0.75];
    x=[-4 -4 -1 -1 ];
    patch(x,y,colorM(machine,:));
    etiqueta=strcat( 'M', num2str(machine));
    text(-3.5,machine-0.5,etiqueta)
    y=[machine-0.9 machine-0.1 machine-0.1 machine-0.9];
    % Operations of each machine
    for oper=1:machine_current_op(machine)
        x = [timesInMaq(machine,oper) timesInMaq(machine,oper) timesFinMaq(machine,oper) timesFinMaq(machine,oper)];
        patch(x,y,colorT(trabMaq(machine,oper),:));
        etiqueta=strcat( 'J', num2str(trabMaq(machine,oper)), ',', num2str(operTrabMaq(machine,oper)) ); 
        text(timesInMaq(machine,oper),machine-0.5,etiqueta)
    end
end
% X axis limits
xlim([-4,makespan+5])
% Remove labels of Y axis and start X axis in 0
grafica=gca;
set(grafica,'YTick',[])
% Line from 0 to machine_number in Y axis for X in 0
x=[0,0];
y=[0,machine_number];
hold on
plot(x,y,'k','LineWidth',1.25)
hold off
end

