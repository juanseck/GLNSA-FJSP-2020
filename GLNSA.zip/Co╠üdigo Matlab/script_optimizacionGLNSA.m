%  Global-Local Neighborhood Search Algorithm (GLNSA)
%
%  Source codes demo version 1.0
%
%  Developed in MATLAB R2015a(7.08)
%
%  Author and programmer: Juan Carlos Seck Tuoh Mora
%
% email:   jseck@uaeh.edu.mx
%          juanseck@gmail.com
%
%
%  Main paper:
%  Juan Carlos Seck Tuoh Mora, Nayeli Jazmin Escamilla Serna, Joselito Medina Marin, 
%  Norberto Hernandez Romero, Irving Barragan Vite, Jose Ramon Corona Armenta,
%  A global-local neighborhood search algorithm and tabu search for flexible job shop scheduling problem
%  PeerJ Computer Science, DOI: http://
%_______________________________________________________________________________________________
% The initial parameters that you need are:
%__________________________________________
% numIndividuos = number of smart-cells
% numGeneraciones = maximum number of iterations
% numEstancamiento = maximum number of stagnation iterations
% probElitista = propbability of elitist smart-cells
% tamVecindad = number of neighbors
%______________________________________________________________________________________________

clear all
nombreProblema = 'la31.fjs';

%Parametros del GLNSA
numIndividuos = 30;
numGeneraciones = 250;
numEstancamiento = 40;
probElitista = 0.02;
tamVecindad = 2;

%Leer datos del problema
[numeroTrabajos, numeroMaquinas, numOperaciones, ~, vectorInicioOperaciones, vectorOperaciones, tablaTiempos, tablaMaquinasFactibles] = leerDatosProblema(nombreProblema);

tic;
[so, sm, mejorMakespan, ~, ~, ~, convergencia] = algoritmoGLNSA(numIndividuos, numGeneraciones, numEstancamiento, probElitista, tamVecindad, numeroTrabajos, numeroMaquinas, numOperaciones, vectorInicioOperaciones, vectorOperaciones, tablaTiempos, tablaMaquinasFactibles);
tiempoF=toc;

%Mejor solucion
disp(['Solucion: ' num2str(mejorMakespan)])
disp(['Tiempo: ' num2str(tiempoF)])


diagramaDeGanttMaquinas(so, sm, numeroTrabajos, numeroMaquinas, numOperaciones, vectorInicioOperaciones, tablaTiempos)

figure(2)
plot(1:size(convergencia,2),convergencia,'linewidth',1.5)
xlim([1,size(convergencia,2)])
title('Optimization of LA31 instance','fontsize',16)
xl=xlabel('Iteration','fontsize',14);
xl.Position(2)=xl.Position(2)-.2;
yl=ylabel('Makespan','fontsize',14);
yl.Position(1)=yl.Position(1)-.2;
yticks(1400:100:2800)
grid on

function [numeroTrabajos, numeroMaquinas, numeroOperaciones, vectorNumOperaciones, vectorInicioOperaciones, vectorOperaciones, tablaTiempos, tablaMaquinasFactibles] = leerDatosProblema(nombreArchivo)
%La función lee la tabla de datos del problema y regresa el número de trabajos, el número de máquinas,
%el vector con el número de operaciones por trabajo, el vector con el número de operacion anterior donde inicia cada
%trabajo, el vector base con las operaciones repetidas para cada trabajo (1,...,1,2,...,2,...,n...n), la tabla de
%tiempos (operaciones/maquinas) y el vector del numero de operacion inicial de cada trabajo, en
%que número de operación empieza tomando el 0 como base

%   Formato de datos:

%   in the first line there are (at least) 2 numbers: the first is the number of jobs and the second the number
%   of machines (the 3rd is not necessary, it is the average number of machines per operation)

%   Every row represents one job: the first number is the number of operations of that job, the second number
%   (let's say k>=1) is the number of machines that can process the first operation; then according to k, there are
%   k pairs of numbers (machine,processing time) that specify which are the machines and the processing times;
%   then the data for the second operation and so on...

%   Example: Fisher and Thompson 6x6 instance, alternate name (mt06)
%   6   6   1
%   6   1   3   1   1   1   3   1   2   6   1   4   7   1   6   3   1   5   6
%   6   1   2   8   1   3   5   1   5   10  1   6   10  1   1   10  1   4   4
%   6   1   3   5   1   4   4   1   6   8   1   1   9   1   2   1   1   5   7
%   6   1   2   5   1   1   5   1   3   5   1   4   3   1   5   8   1   6   9
%   6   1   3   9   1   2   3   1   5   5   1   6   4   1   1   3   1   4   1
%   6   1   2   3   1   4   3   1   6   9   1   1   10  1   5   4   1   3   1

%   first row = 6 jobs and 6 machines 1 machine per operation
%   second row: job 1 has 6 operations, the first operation can be processed by 1 machine that is machine 3 with processing time 1.
%   Reference: http://people.idsia.ch/~monaldo/fjsp.html

%   Leer archivo
archivo=fopen(nombreArchivo,'r');
%   Buscar todos los datos numéricos enteros que definen el problema
datos=fscanf(archivo,'%f');

% Obtener datos numeroTrabajos, numeroMaquinas
numeroTrabajos=datos(1);
numeroMaquinas=datos(2);

% Tercer dato numérico no importa

%Inicializa como vacío vectorOperaciones
vectorOperaciones=[];

%   Indices para recorrer trabajos, operaciones y posición de en el arreglo
%   de datos
indice=4;
nt=1;
%Ciclo para recorrer trabajos
while(nt<=numeroTrabajos)
    %   Tomar numero de operaciones para el trabajo nt y ponerlo en los
    %   vectores vectorNumOperaciones y vectorInicio
    vectorNumOperaciones(nt)=datos(indice);
    vectorInicioOperaciones(nt)=sum(vectorNumOperaciones(1:nt-1));
    %Agregar operaciones repetidas para cada trabajo para formar solucion
    %base
    operacionesTrabajo=ones(1,vectorNumOperaciones(nt))*nt;
    vectorOperaciones=[vectorOperaciones operacionesTrabajo];
    
    %Ciclo para recorrer las operaciones del trabajo nt
    for numOper=1:vectorNumOperaciones(nt)
        %Leer numero de maquinas que pueden hacer la operación actual
        indice=indice+1;
        numMaq=datos(indice);
        %Ciclo para recorrer maquinas y tiempos capaces de realizar dicha
        %operacion
        for i=1:numMaq
            %Incrementar indice, leer maquina, incrementar indice, leer tiempo
            indice=indice+1;
            maquina=datos(indice);
            indice=indice+1;
            tiempo=datos(indice);
            %Agregar tiempo en la tablaTiempos, en el renglon
            %vectorInicioOperaciones(nt)+numOper y la columna maquina
            tablaTiempos(vectorInicioOperaciones(nt)+numOper,maquina)=tiempo;
        end
    end
    %Pasar a los datos para el siguiente trabajo
    indice=indice+1;
    nt=nt+1;
end

%Numero de operaciones
numeroOperaciones=length(vectorOperaciones);
%   Llenar tabla de máquinas disponibles para cada operación
%   Maquinas disponibles
tablaMaquinasFactibles=[];
%lista_maquinas = 1:numeroMaquinas;
%   Ciclo para recorrer tabla_tiempos
for oper=1:length(tablaTiempos)
    %   Obtener máquinas factibles para operación oper
    indices_factibles = tablaTiempos(oper,:) ~= 0;
    tablaMaquinasFactibles=[tablaMaquinasFactibles; indices_factibles];
end
end

function [mejorSO, mejorSM, mejorMakespan, PoblacionSO, PoblacionSM, PoblacionMakespan, convergencia] = algoritmoGLNSA(numIndividuos, numGeneraciones, numEstancamiento, probElitista, tamVecindad, numeroTrabajos, numeroMaquinas, numOperaciones, vectorInicioOperaciones, vectorOperaciones, tablaTiempos, tablaMaquinasFactibles)
%   Implementación del algoritmo GLNSA

%Arreglos de población, se harna lo más sencillos posibles para velocidad
PoblacionSO=zeros(numIndividuos,numOperaciones);
PoblacionSM=zeros(numIndividuos,numOperaciones);
PoblacionMakespan=zeros(numIndividuos,1);

%Ciclo para generar individuos iniciales
for i=1:numIndividuos
    %Generar individuo aleatorio
    [PoblacionSO(i,:),PoblacionSM(i,:)] = generarIndividuoAleatorio(numeroMaquinas,numOperaciones,vectorOperaciones,tablaMaquinasFactibles);
end

%Calificar poblacion
[PoblacionMakespan] = calificarPoblacion(PoblacionSO, PoblacionSM, PoblacionMakespan, numeroTrabajos, numeroMaquinas, numOperaciones,numIndividuos,vectorInicioOperaciones, tablaTiempos, 1);
%Seleccionar mejor de la poblacion
[mejorSO, mejorSM, mejorMakespan] = mejorIndividuo(PoblacionSO, PoblacionSM, PoblacionMakespan);

%Numero de individuos elitistas
numIndEl=round(numIndividuos*probElitista);
%Se actualiza para dejar un resto par
if mod(numIndividuos-numIndEl,2)==1
    numIndEl = numIndEl+1;
end

%Contador de iteraciones
contIt=1;
%Contador de estancamiento
contEst=1;
%Bandera para ciclo while
banderaCiclo=1;

%Convergencia
convergencia=[];
convergencia(contIt)=mejorMakespan;
 
%Ciclo de optimización
while(banderaCiclo)
    %Seleccion de nueva poblacion
    [PoblacionSO, PoblacionSM, PoblacionMakespan] = seleccion(PoblacionSO, PoblacionSM, PoblacionMakespan, numIndividuos, numIndEl, 2);
    %Aplicar vecindad GLNSA a cada individuo y obtener poblacion mejorada
    [PoblacionSO, PoblacionSM, PoblacionMakespan] = aplicacionVecindadGLNSA(PoblacionSO, PoblacionSM, PoblacionMakespan, tamVecindad, numIndividuos, numeroTrabajos, numeroMaquinas, numOperaciones, vectorInicioOperaciones, tablaTiempos, tablaMaquinasFactibles, numIndEl);
    %Hacer búsqueda tabú
    [PoblacionSO, PoblacionSM, PoblacionMakespan] = busquedaTabuPoblacion(PoblacionSO, PoblacionSM, PoblacionMakespan, numIndividuos, contIt, numeroTrabajos, numeroMaquinas, numOperaciones, vectorInicioOperaciones, tablaTiempos, tablaMaquinasFactibles, numIndEl);
    %Seleccionar mejor de la nueva poblacion
    [nuevaMejorSO, nuevaMejorSM, nuevaMejorMakespan] = mejorIndividuo(PoblacionSO, PoblacionSM, PoblacionMakespan);
    %Ver si es mejor que la solucion anterior y reemplazar
    if nuevaMejorMakespan < mejorMakespan
        mejorSO = nuevaMejorSO;
        mejorSM = nuevaMejorSM;
        mejorMakespan = nuevaMejorMakespan;
        contEst=1;
    else
        %En caso contrario incrementar contador estancamiento
        contEst=contEst+1;
    end
    %Checar condicion de paro
    if ((contEst>=numEstancamiento) || (contIt>=numGeneraciones))
        banderaCiclo=0;
    end
    %Imprimir mejor makespan
    if mod(contIt,20)==0
        disp(['Iteracion: ' num2str(contIt) ' Makespan: ' num2str(mejorMakespan)]) 
    end
    contIt=contIt+1;
    
    %Convergencia
    convergencia(contIt)=mejorMakespan;
    
end

end

function [so,sm] = generarIndividuoAleatorio(numeroMaquinas,numOperaciones,vectorOperaciones,tablaMaquinasFactibles)
%   Entrada
%   vectorOperaciones es la solución base con repeticiones
%   tablaMaquinasFactibles es de celdas, cada renglón es una operación en el orden base que contiene como columnas 
%   las máquinas que pueden procesar cada operación

%Permutacion de operaciones
indices=randperm(numOperaciones);
so=vectorOperaciones(indices);

%Asignacion aleatoria de maquinas factibles para cada operacion en el orden
%base, siguiendo la codificación del HA
lista_maquinas = 1:numeroMaquinas;
sm=zeros(1,numOperaciones);
for i=1:numOperaciones
    maquinas=tablaMaquinasFactibles(i,:);
    factibles = lista_maquinas(logical(maquinas));
    numMaquinas=length(factibles);
    indMaquina=randi([1 numMaquinas]);
    maquina=factibles(indMaquina);
    sm(i)=maquina;
end

end

function [PobMk] = calificarPoblacion(PobSO, PobSM, PobMk, numeroTrabajos, numeroMaquinas, numOperaciones,numIndividuos,vectorInicioOperaciones, tablaTiempos, inicio)
%Calcular el makespan de cada individuo de Poblacion
for i=inicio:numIndividuos
    PobMk(i) = calcularMakespanSimple(PobSO(i,:), PobSM(i,:), numeroTrabajos, numeroMaquinas, numOperaciones, vectorInicioOperaciones, tablaTiempos);
end
end

function [makespan] = calcularMakespanSimple(so,sm,numeroTrabajos, numeroMaquinas, numOperaciones, vectorInicioOperaciones, tablaTiempos)
%Calcula el makespan de una solucion dada del FJSP dada la codificación HA
%Solucion dos vectores (operaciones y máquina por operación) y regresa makespan

%Inicializar makespan
makespan = 0;

%Tiempo actual final en que está cada máquina
tiempoActualMaquina=zeros(1,numeroMaquinas);
%Operación actual en que se encuentra cada trabajo
operActualTrabajo=ones(1,numeroTrabajos);
%Tiempo actual en que se encuentra cada trabajo
tiempoActualTrabajo=zeros(1,numeroTrabajos);

for i=1:numOperaciones
    trabajo=so(i);
    operacion=operActualTrabajo(trabajo);
    %Actualizar para siguiente iteracion
    operActualTrabajo(trabajo)=operActualTrabajo(trabajo)+1;
    %Maquina de la operacion
    posicion=vectorInicioOperaciones(trabajo)+operacion;
    maquina=sm(posicion);
    %Tiempo de proceso
    tiempo=tablaTiempos(posicion,maquina);
    %Obtener tiempo inicial en que la operacion puede empezar
    tiempoInicial=tiempoActualTrabajo(trabajo);
    aux=tiempoActualMaquina(maquina);
    if aux > tiempoInicial
        tiempoInicial=aux;
    end
    %Acomodar operacion en máquina y trabajo
    tiempoActualMaquina(maquina)=tiempoInicial+tiempo;
    tiempoActualTrabajo(trabajo)=tiempoInicial+tiempo;
    %Actualizar makespan
    if makespan < tiempoInicial+tiempo
        makespan = tiempoInicial+tiempo;
    end
end
end

function [mejorSO, mejorSM, mejorMk, indice] = mejorIndividuo(PobSO, PobSM, PobMk)
%Individuo con el makespan minimo de Poblacion
[mejorMk, indice] = min(PobMk);
mejorSO=PobSO(indice,:);
mejorSM=PobSM(indice,:);
end

function [nuevaPobSO, nuevaPobSM, nuevaPobMk] = seleccion(PobSO, PobSM, PobMk, numsoluciones, numElitista, numCompetidores)
% Seleccion completa con elitismo y torneo
[nuevaPobSO, nuevaPobSM, nuevaPobMk] = seleccionElitista(PobSO, PobSM, PobMk, numElitista);
ind=numElitista+1;
while (ind<=numsoluciones)
    indGanador = seleccionTorneo(PobMk, numsoluciones, numCompetidores);
    nuevaPobSO(ind,:)=PobSO(indGanador,:);
    nuevaPobSM(ind,:)=PobSM(indGanador,:);
    nuevaPobMk(ind)=PobMk(indGanador);
    ind=ind+1;
end

end

function [nuevaPobSO, nuevaPobSM, nuevaPobMk] = seleccionElitista(PobSO, PobSM, PobMk, numElitista)
%Selección elitista de numero individuos de Poblacion
nuevaPobSO=PobSO;
nuevaPobSM=PobSM;
nuevaPobMk=PobMk;
[ ~, indices ] = sort( PobMk);
for i=1:numElitista
    nuevaPobSO(i,:)=PobSO(indices(i),:);
    nuevaPobSM(i,:)=PobSM(indices(i),:);
    nuevaPobMk(i)=PobMk(indices(i));
end
end

function indGanador= seleccionTorneo(PobMk,numsoluciones,numCompetidores)
%Selecciona un ganador por torneo entre numCompetidores aleatorios de Poblacion
indices=randperm(numsoluciones,numCompetidores);
[~,ind]=min(PobMk(indices));
indGanador=indices(ind);
end

function [PoblacionSO, PoblacionSM, PoblacionMakespan] = aplicacionVecindadGLNSA(PoblacionSO, PoblacionSM, PoblacionMakespan, tamVecindad, numIndividuos, numeroTrabajos, numeroMaquinas, numeroOperaciones, vectorInicioOperaciones, tablaTiempos, tablaMaquinasFactibles, inicio)
for i=inicio+1:numIndividuos
    so=PoblacionSO(i,:);
    sm=PoblacionSM(i,:);
    [mejor_so, mejor_sm, mejor_mk] = vecindadGLNSA(so, sm, tamVecindad, PoblacionSO, numIndividuos, numeroTrabajos, numeroMaquinas, numeroOperaciones, vectorInicioOperaciones, tablaTiempos, tablaMaquinasFactibles);
    PoblacionSO(i,:)=mejor_so;
    PoblacionSM(i,:)=mejor_sm;
    PoblacionMakespan(i)=mejor_mk;
end
end

function [mejor_so, mejor_sm, mejor_mk] = vecindadGLNSA(so, sm, tamVecindad, PoblacionSO, numIndividuos, numeroTrabajos, numeroMaquinas, numOperaciones, vectorInicioOperaciones, tablaTiempos, tablaMaquinasFactibles)
%Obtiene el mejor de vecino de una solucion usando distintas variantes

mejor_mk=inf;

%Ciclo para vecindad
for i=1:tamVecindad    
    opcion=rand;
    if opcion <= 0.5
        [nuevo_so, nuevo_sm, nuevo_mk] = insercionClasica(so, sm, numeroTrabajos, numeroMaquinas, numOperaciones,vectorInicioOperaciones, tablaTiempos, tablaMaquinasFactibles);
    elseif opcion > 0.5 && opcion <= 0.75  
        [nuevo_so, nuevo_sm, nuevo_mk] = intercambioClasico(so, sm, numeroTrabajos, numeroMaquinas, numOperaciones, vectorInicioOperaciones, tablaTiempos, tablaMaquinasFactibles);
    else
        ind=randi(numIndividuos);
        sof=PoblacionSO(ind,:);
        [nuevo_so, nuevo_sm, nuevo_mk] = pathRelinkingClasico(so, sm, sof, numeroTrabajos, numeroMaquinas, numOperaciones, vectorInicioOperaciones, tablaTiempos,tablaMaquinasFactibles);
    end
    %Seleccionar mejor opcion
    if nuevo_mk < mejor_mk
        mejor_so=nuevo_so;
        mejor_sm=nuevo_sm;
        mejor_mk=nuevo_mk;
    end
end

end

function [nuevo_so, nuevo_sm, nuevo_mk] = pathRelinkingClasico(so, sm, sof, numeroTrabajos, numeroMaquinas, numOperaciones, vectorInicioOperaciones, tablaTiempos,tablaMaquinasFactibles)
%Hace el path relinking buscando mover una operacion seleccionada al azar

%Seleccionar operacion al azar evitando que se pueda tomar la penultima
posicionPR=randi(numOperaciones-4);
secuencia1=sof;
secuencia2=so;
secuenciaf = pathRelinkingSO(secuencia1,secuencia2,numOperaciones,posicionPR);
nuevo_so=secuenciaf;
%Mutar maquinas
nuevo_sm=sm;
if rand<=0.1
    [nuevo_sm] = mutacionMaquinas(numeroMaquinas, numOperaciones,sm,tablaMaquinasFactibles);
end
%Calcular makespan de nuevaSolucion
[nuevo_mk] = calcularMakespanSimple(nuevo_so,nuevo_sm,numeroTrabajos, numeroMaquinas, numOperaciones, vectorInicioOperaciones, tablaTiempos);

end

function secuenciaf = pathRelinkingSO(secuencia1,secuencia2,longitudSec,posicion)
%Hace el path relinking de secuencia1 a secuencia2 hasta la posicion
secuenciaf=secuencia1;
for i=1:posicion
    operacion=secuencia2(i);
    if secuenciaf(i)~=operacion
        %Buscar elemento igual a operacion
        j=i+1;
        if j>=longitudSec
            break
        end
        while(1)
            if secuenciaf(j)==operacion
                %Hacer intercambio y salir
                secuenciaf(j)=secuenciaf(i);
                secuenciaf(i)=operacion;
                break
            end
            j=j+1;
            if j>=longitudSec
                break
            end
        end
    end
end

end

function [nuevo_so, nuevo_sm, nuevo_mk] = insercionClasica(so, sm, numeroTrabajos, numeroMaquinas, numOperaciones,vectorInicioOperaciones, tablaTiempos, tablaMaquinasFactibles)
%Hace una insercion de operaciones de forma clásica
nuevo_so=so;
nuevo_sm=sm;
operacion=randi(numOperaciones);
%Seleccionar lugar de insercion hasta que no se el mismo lugar ni el mismo trabajo
ind=randi(numOperaciones);
while(ind==operacion)
    ind=randi(numOperaciones);
end
%Hacer insercion en nuevaSolucion
%Operaciones
nuevo_so(ind)=so(operacion);
if operacion>ind
    nuevo_so(ind+1:operacion)=so(ind:operacion-1);
else
    nuevo_so(operacion:ind-1)=so(operacion+1:ind);
end
%Maquinas
if rand<=0.1
    [nuevo_sm] = mutacionMaquinas(numeroMaquinas, numOperaciones,sm,tablaMaquinasFactibles);
end
%Calcular makespan de nuevaSolucion
[nuevo_mk] = calcularMakespanSimple(nuevo_so,nuevo_sm,numeroTrabajos, numeroMaquinas, numOperaciones, vectorInicioOperaciones, tablaTiempos);
end

function [nuevo_so, nuevo_sm, nuevo_mk] = intercambioClasico(so, sm, numeroTrabajos, numeroMaquinas, numOperaciones, vectorInicioOperaciones, tablaTiempos, tablaMaquinasFactibles)
%Hace n intercambios de dos operaciones en la secuencia de operaciones
%de forma clásica 
%Para las máquinas se hace mutacion de 8 maquinas
nuevo_so=so;
nuevo_sm=sm;
for i=1:8
    %Seleccionar operacion aleatoria en la ruta crítica
    ind=randi(numOperaciones);
    operacion=nuevo_so(ind);
    %Seleccionar lugar de intercambio
    ind2=randi(numOperaciones);
    operacion2=nuevo_so(ind2);
    while(operacion2==operacion)
        ind2=randi(numOperaciones);
        operacion2=nuevo_so(ind2);
    end
    %Hacer intercambio
    nuevo_so(ind)=operacion2;
    nuevo_so(ind2)=operacion;
end
%Mutar maquinas
if rand<=0.1
    [nuevo_sm] = mutacionMaquinas(numeroMaquinas, numOperaciones,sm,tablaMaquinasFactibles);
end
%Calcular makespan de nuevaSolucion
[nuevo_mk] = calcularMakespanSimple(nuevo_so,nuevo_sm,numeroTrabajos, numeroMaquinas, numOperaciones, vectorInicioOperaciones, tablaTiempos);
end

function [nuevaSol] = mutacionMaquinas(numeroMaquinas, numOper,solucion,tablaMaquinasFactibles)
%Mutación de máquinas
%Se seleccionan la mitad aleatoria de las posiciones de la cadena
%Para cada posición, se cambia el valor a otra máquina que pueda realizar la operación correspondiente
%Para hacer esto se necesita conocer la secuencia de máquinas, la operacion correspondiente, las máquinas que
%pueden hacer dicha operación
%En el algoritmo, la secuencia_maquinas está por bloques, cada bloque tiene el mismo orden de
%operaciones por trabajo que tablaMaquinasFactibles, empezando desde el bloque del trabajo 1, luego el bloque del trabajo 2, así sucesivamente

nuevaSol = solucion;
lista_maquinas = 1:numeroMaquinas;
%Indices de operaciones a modificar
indices=randperm(numOper,floor(numOper/2));
for i=1:length(indices)
    maquinas=tablaMaquinasFactibles(indices(i),:);
    factibles = lista_maquinas(logical(maquinas));
    numMaquinas=length(factibles);
    indMaquina=randi([1 numMaquinas]);
    maq=factibles(indMaquina);
    nuevaSol(indices(i))=maq;
end

end

function [PobSO, PobSM, PobMk] = busquedaTabuPoblacion(PobSO, PobSM, PobMk, numIndividuos, iteracionesTabu, numeroTrabajos, numeroMaquinas, numOperaciones,vectorInicioOperaciones, tablaTiempos, tablaMaquinasFactibles, inicio)
%Hace la busqueda tabu sobre la proporcion de poblacion y regresa la poblacion mejorada
for i=inicio+1:numIndividuos
    [PobSO(i,:), PobSM(i,:), PobMk(i)] = busquedaTabu4(PobSO(i,:), PobSM(i,:), PobMk(i), iteracionesTabu, numeroTrabajos, numeroMaquinas, numOperaciones,vectorInicioOperaciones, tablaTiempos, tablaMaquinasFactibles);
end

end

function [mejorsolucionSO, mejorsolucionSM, mejorsolucionMk] = busquedaTabu4(solucionSO, solucionSM, solucionMk, iteracionesTabu, numeroTrabajos, numeroMaquinas, numOperaciones,vectorInicioOperaciones, tablaTiempos, tablaMaquinasFactibles)
%Lista tabu inicializada
Tabla_Tabu=zeros(numOperaciones,numeroMaquinas);
mejorsolucionSO = solucionSO;
mejorsolucionSM = solucionSM;
mejorsolucionMk = solucionMk;

%Calcular ruta crítica para solucion actual
iteracion=1;
while(iteracion<=mod(iteracionesTabu,30)+1)
    [bandera, mejor_so, mejor_sm, mejor_mk, mejor_opOrd, mejor_maquina, mejor_numero_maqf, nOpC] = vecinoSimplificadoTS14(solucionSO, solucionSM, solucionMk, numeroTrabajos, numeroMaquinas, numOperaciones, vectorInicioOperaciones, tablaTiempos, tablaMaquinasFactibles, iteracion, Tabla_Tabu);
    if bandera==0
        % No se encontró ni mejor, ni no tabú ni tabú; salir del ciclo
        break
    end
    %Actualizar tabla tabu
    Tabla_Tabu(mejor_opOrd,mejor_maquina)=iteracion+nOpC+mejor_numero_maqf;
    %Tabla_Tabu(seleccion_operacion,seleccion_maquina)=iteracion+9;
    %Si el makespan nuevo es mejor que el actual, sustituir solucion
    if bandera==3
        mejorsolucionSO=mejor_so;
        mejorsolucionSM=mejor_sm;
        mejorsolucionMk=mejor_mk;
    end
    %Nueva solucion para vecindad 
    iteracion = iteracion+1;
    solucionSO=mejor_so;
    solucionSM=mejor_sm;
    solucionMk=mejor_mk;
end
end

function [bandera, mejor_so, mejor_sm, mejor_mk, mejor_opOrd, mejor_maquina, mejor_numero_maqf, nOpC] = vecinoSimplificadoTS14(solucionSO, solucionSM, solucionMk, numeroTrabajos, numeroMaquinas, numOperaciones, vectorInicioOperaciones, tablaTiempos, tablaMaquinasFactibles, iteracion, Tabla_Tabu)
%Simplificacion de Nopt1
%Se calcula un vecino seleccionando nOpC operaciones críticas y cambiando
%sus máquinas por otras si hay factibles
%Regresa el vecino ya sea el mismo por no tener otra máquina posible (bandera=0),
%por no mejorar el makespan pero no ser tabú (bandera=1),
%o por mejorar el makespan (bandera=2)

%Datos para guardar la nueva solución, ya sea mejor, no tabú o tabú
mejor_so=solucionSO; 
mejor_sm=solucionSM;
mejor_mk=solucionMk;

bandera=0; %0.- no se encontró nueva solución de ningñún tipo. 1.- solución tabú. 2.- solución no tabú. 3.- solución mejor
antiguedad=inf;

%Ruta crítica
[nOpC, ~, ~, maqRC, indSMRC, ~] = rutaCriticaSimple(solucionSO, solucionSM, numeroTrabajos, numeroMaquinas, numOperaciones, vectorInicioOperaciones, tablaTiempos);

%Posiciones aleatorias en RC
%Guardar operaciones consecutivas y máquinas a las que corresponden
posicionesMaq=indSMRC;
maquinas=maqRC;

%Maquinas factibes distintas que pueden hacer la misma operacion para las
%dos operaciones seleccionadas
lista_maquinas = 1:numeroMaquinas;

%Ciclo para recorrer operaciones críticas
%seleccion=0;
for i=1:nOpC
    opOrd=indSMRC(i);
    indMaqFac = tablaMaquinasFactibles(posicionesMaq(i),:);
    indMaqFac(maquinas(i))=false;
    factibles = lista_maquinas(logical(indMaqFac));
    numfac = length(factibles);
    for j=1:numfac
        soAux=solucionSO;
        smAux=solucionSM;
        maquinaNueva=factibles(j);
        smAux(posicionesMaq(i))=maquinaNueva;
        [nuevo_makespan] = calcularMakespanSimple(soAux,smAux,numeroTrabajos, numeroMaquinas, numOperaciones, vectorInicioOperaciones, tablaTiempos);
        if (nuevo_makespan < mejor_mk)
            %Se mejora la solución, actualizar solución a regresar y bandera a 3
            mejor_so=soAux;
            mejor_sm=smAux;
            mejor_mk=nuevo_makespan;
            mejor_opOrd=opOrd;
            mejor_maquina=maquinaNueva;
            mejor_numero_maqf=numfac+1;
            bandera=3;
        end
        if (bandera~=3) && (Tabla_Tabu(opOrd,maquinaNueva)<iteracion) 
            %La solución no mejora al mk pero no es tabú, guardar el mejor no tabú
            if (bandera~=2) || (nuevo_makespan<nuevo_mk)
                nuevo_so=soAux;
                nuevo_sm=smAux;
                nuevo_mk=nuevo_makespan;
                nuevo_opOrd=opOrd;
                nuevo_maquina=maquinaNueva;
                nuevo_numero_maqf=numfac+1;
                bandera=2;
            end
        end
        if (bandera<=1) && (Tabla_Tabu(opOrd,maquinaNueva)>=iteracion) 
            %La solución es tabú y no se ha encontrado otra mejor ni no tabú, guardar la solución tabú más antigua
            if (bandera~=1) || (Tabla_Tabu(opOrd,maquinaNueva)<antiguedad) 
                nuevo_so=soAux;
                nuevo_sm=smAux;
                nuevo_mk=nuevo_makespan;
                nuevo_opOrd=opOrd;
                nuevo_maquina=maquinaNueva;
                nuevo_numero_maqf=numfac+1;
                antiguedad=Tabla_Tabu(opOrd,maquinaNueva);
                bandera=1;
            end
        end
    end
end
                    
%Si solo se encontró una solución no tabú o tabú, reemplazar al mejor
if (bandera>0) && (bandera<3)
    mejor_so=nuevo_so;
    mejor_sm=nuevo_sm;
    mejor_mk=nuevo_mk;
    mejor_opOrd=nuevo_opOrd;
    mejor_maquina=nuevo_maquina;
    mejor_numero_maqf=nuevo_numero_maqf;
end

end

function [tamRC, trabRC, opeRC, maqRC, indSMRC, indSORC] = rutaCriticaSimple(so, sm, numeroTrabajos, numeroMaquinas, numOperaciones, vectorInicioOperaciones, tablaTiempos)

%Calcular ruta crítica

tiemposInMaq=zeros(numeroMaquinas,numeroTrabajos*3);
tiemposFinMaq=zeros(numeroMaquinas,numeroTrabajos*3);
trabMaq=zeros(numeroMaquinas,numeroTrabajos*3);
operTrabMaq=zeros(numeroMaquinas,numeroTrabajos*3);
indSM=zeros(numeroMaquinas,numeroTrabajos*3);
indSO=zeros(numeroMaquinas,numeroTrabajos*3);
tiemposInTrab=zeros(numeroTrabajos,numeroMaquinas*3);
tiemposFinTrab=zeros(numeroTrabajos,numeroMaquinas*3);
maqTrab=zeros(numeroTrabajos,numeroMaquinas*3);
indRenMaqTrab=zeros(numeroTrabajos,numeroMaquinas*3);

%Calcular makespan
makespan = 0;
%Tiempo actual final en que está cada máquina
tiempoActualMaquina=zeros(1,numeroMaquinas);
%Operación actual en que se encuentra cada trabajo
operActualMaquina=zeros(1,numeroMaquinas);
%Tiempo actual en que se encuentra cada trabajo
tiempoActualTrabajo=zeros(1,numeroTrabajos);
%Operación actual en que se encuentra cada trabajo
operActualTrabajo=zeros(1,numeroTrabajos);

for i=1:numOperaciones
    trabajo=so(i);
    %Actualizar operacion actual
    operActualTrabajo(trabajo)=operActualTrabajo(trabajo)+1;
    operacion=operActualTrabajo(trabajo);
    %Maquina de la operacion
    posicion=vectorInicioOperaciones(trabajo)+operacion;
    maquina=sm(posicion);
    %Tiempo de proceso
    tiempo=tablaTiempos(posicion,maquina);
    %Obtener tiempo inicial en que la operacion puede empezar
    tiempoInicial=tiempoActualTrabajo(trabajo);
    aux=tiempoActualMaquina(maquina);
    if aux > tiempoInicial
        tiempoInicial=aux;
    end
    %Acomodar operacion en máquina y trabajo
    tiempoActualMaquina(maquina)=tiempoInicial+tiempo;
    tiempoActualTrabajo(trabajo)=tiempoInicial+tiempo;
    operActualMaquina(maquina)=operActualMaquina(maquina)+1;
    %Actualizar makespan
    if makespan < tiempoInicial+tiempo
        makespan = tiempoInicial+tiempo;
    end
    %Llenar tablas para RC y diagrama de Gantt
    tiemposInMaq(maquina,operActualMaquina(maquina))=tiempoInicial;
    tiemposFinMaq(maquina,operActualMaquina(maquina))=tiempoInicial+tiempo;
    trabMaq(maquina,operActualMaquina(maquina))=trabajo;
    operTrabMaq(maquina,operActualMaquina(maquina))=operActualTrabajo(trabajo);
    indSM(maquina,operActualMaquina(maquina))=posicion;
    indSO(maquina,operActualMaquina(maquina))=i;
    tiemposInTrab(trabajo,operActualTrabajo(trabajo))=tiempoInicial;
    tiemposFinTrab(trabajo,operActualTrabajo(trabajo))=tiempoInicial+tiempo;
    maqTrab(trabajo,operActualTrabajo(trabajo))=maquina;
    indRenMaqTrab(trabajo,operActualTrabajo(trabajo))=operActualMaquina(maquina);
end

%Encontrar máquina con última operación con valor igual a makespan para empezar la ruta
%crítica hacia atrás

%Arreglos auxiliares para calcular RC
tamRutaCritica=0;
trabRutaCompleta=zeros(1,numeroTrabajos*3);
operRutaCompleta=zeros(1,numeroTrabajos*3);
maqRutaCompleta=zeros(1,numeroTrabajos*3);
indSMRutaCompleta=zeros(1,numeroTrabajos*3);
indSORutaCompleta=zeros(1,numeroTrabajos*3);


%Seleccionar maquina inicial aleatoria entre las que tiene tiempo final
%igual a makespan
maqMk=zeros(1,numeroMaquinas);
numMaqMk=0;
for i=1:numeroMaquinas
    if tiemposFinMaq(i,operActualMaquina(i)) == makespan
        numMaqMk=numMaqMk+1;
        maqMk(numMaqMk)=i;
    end
end

%Obtener indice aleatorio para última operación en la ruta crítica
maquina=maqMk(randi([1,numMaqMk]));
operActualMaq=operActualMaquina(maquina);
trabajo=trabMaq(maquina,operActualMaq);
operacion=operTrabMaq(maquina,operActualMaq);
indiceSM=indSM(maquina,operActualMaq);
indiceSO=indSO(maquina,operActualMaq);
operActualTrab=operActualTrabajo(trabajo);


%Ciclo para fomar ruta crítica
bandera=1;
while(bandera)
    %Agregar indice a rutaCompleta
    tamRutaCritica=tamRutaCritica+1;
    indSMRutaCompleta(tamRutaCritica)=indiceSM;
    indSORutaCompleta(tamRutaCritica)=indiceSO;
    trabRutaCompleta(tamRutaCritica)=trabajo;
    operRutaCompleta(tamRutaCritica)=operacion;
    maqRutaCompleta(tamRutaCritica)=maquina;
    %Ver si ya se llegó al tiempo cero, primer trabajo de la ruta crítica
    tiempoI=tiemposInMaq(maquina,operActualMaq);
    if tiempoI<=0
        bandera=0;
    else
        %Seguir recorriendo ruta crítica
        %Ver que sigue hacia atrás por mayor tiempo, si máquina u operación anterior
        %Máquina
        maquinaAnt=maquina;
        indOperMaqAnt=operActualMaq-1;
        if indOperMaqAnt>0
            tiempoMaqAnt=tiemposFinMaq(maquinaAnt,indOperMaqAnt);
        else
            %La maquina ya no tiene mas trabajos, poner tiempo como cero
            tiempoMaqAnt=0;
        end
        %Operación
        trabajoAnt=trabajo;
        indOperTrabAnt=operActualTrab-1;
        if indOperTrabAnt>0
            tiempoTrabAnt=tiemposFinTrab(trabajoAnt,indOperTrabAnt);
        else
            %La operacion ya nom tiene mas trabajos, poner tiempo como cero
            tiempoTrabAnt=0;
        end
        %Elegir si se cambia de máquina con el tiempo más alto
        aleatorio=rand;
        if ((tiempoMaqAnt==tiempoI)&&(tiempoMaqAnt>tiempoTrabAnt)) || ((tiempoMaqAnt==tiempoTrabAnt)&&(aleatorio<=0.5))
            maquina=maquinaAnt;
            operActualMaq=indOperMaqAnt;
            trabajo=trabMaq(maquina,operActualMaq);
            operacion=operTrabMaq(maquina,operActualMaq);
            indiceSM=indSM(maquina,operActualMaq);
            indiceSO=indSO(maquina,operActualMaq);
            operActualTrab=operacion;
        elseif ((tiempoTrabAnt==tiempoI)&&(tiempoMaqAnt<tiempoTrabAnt)) || ((tiempoMaqAnt==tiempoTrabAnt)&&(aleatorio>0.5))
            maquina=maqTrab(trabajo,indOperTrabAnt);
            trabajo=trabajoAnt;
            operacion=indOperTrabAnt;
            operActualMaq=indRenMaqTrab(trabajo,operacion);
            indiceSM=indSM(maquina,operActualMaq);
            indiceSO=indSO(maquina,operActualMaq);
            operActualTrab=operacion;
        end
    end
end
%Poner ruta crítica con el número de operaciones correcto y en sentido
%inverso a rutaCompleta

tamRC=tamRutaCritica;
trabRC=trabRutaCompleta(tamRutaCritica:-1:1);
opeRC=operRutaCompleta(tamRutaCritica:-1:1);
maqRC=maqRutaCompleta(tamRutaCritica:-1:1);
indSMRC=indSMRutaCompleta(tamRutaCritica:-1:1);
indSORC=indSORutaCompleta(tamRutaCritica:-1:1);

end

function diagramaDeGanttMaquinas(so, sm, numeroTrabajos, numeroMaquinas, numOperaciones, vectorInicioOperaciones, tablaTiempos)
%Calcular makespan simple y llenar tabla de máquinas con tiempo inicial,
%tiempo final, trabajo y operación en cada caso

tiemposInMaq=zeros(numeroMaquinas,numeroTrabajos*2);
tiemposFinMaq=zeros(numeroMaquinas,numeroTrabajos*2);
trabMaq=zeros(numeroMaquinas,numeroTrabajos*2);
operTrabMaq=zeros(numeroMaquinas,numeroTrabajos*2);

%Calcular makespan
makespan = 0;
%Tiempo actual final en que está cada máquina
tiempoActualMaquina=zeros(1,numeroMaquinas);
%Operación actual en que se encuentra cada maquina
operActualMaquina=zeros(1,numeroMaquinas);
%Tiempo actual en que se encuentra cada trabajo
tiempoActualTrabajo=zeros(1,numeroTrabajos);
%Operación actual en que se encuentra cada trabajo
operActualTrabajo=zeros(1,numeroTrabajos);

for i=1:numOperaciones
    trabajo=so(i);
    %Actualizar operacion actual
    operActualTrabajo(trabajo)=operActualTrabajo(trabajo)+1;
    operacion=operActualTrabajo(trabajo);
    %Maquina de la operacion
    posicion=vectorInicioOperaciones(trabajo)+operacion;
    maquina=sm(posicion);
    %Tiempo de proceso
    tiempo=tablaTiempos(posicion,maquina);
    %Obtener tiempo inicial en que la operacion puede empezar
    tiempoInicial=tiempoActualTrabajo(trabajo);
    aux=tiempoActualMaquina(maquina);
    if aux > tiempoInicial
        tiempoInicial=aux;
    end
    %Acomodar operacion en máquina y trabajo
    tiempoActualMaquina(maquina)=tiempoInicial+tiempo;
    tiempoActualTrabajo(trabajo)=tiempoInicial+tiempo;
    operActualMaquina(maquina)=operActualMaquina(maquina)+1;
    %Actualizar makespan
    if makespan < tiempoInicial+tiempo
        makespan = tiempoInicial+tiempo;
    end
    %Llenar tablas para RC y diagrama de Gantt
    tiemposInMaq(maquina,operActualMaquina(maquina))=tiempoInicial;
    tiemposFinMaq(maquina,operActualMaquina(maquina))=tiempoInicial+tiempo;
    trabMaq(maquina,operActualMaquina(maquina))=trabajo;
    operTrabMaq(maquina,operActualMaquina(maquina))=operActualTrabajo(trabajo);
end


%Grafica el diagrama de Gantt de una solucion para el problema de FJSP
%Colores del diagrama
colorT=colormap(hsv(numeroTrabajos));
colorM=colormap(lines(numeroMaquinas));

%Grafica del diagrama
figure(1);
clf
grid on
grid minor
%Ciclo para maquinas
for maquina=1:numeroMaquinas
    y=[maquina-0.75 maquina-0.25 maquina-0.25 maquina-0.75];
    x=[-4 -4 -1 -1 ];
    patch(x,y,colorM(maquina,:));
    etiqueta=strcat( 'M', num2str(maquina));
    text(-3.5,maquina-0.5,etiqueta)
    y=[maquina-0.9 maquina-0.1 maquina-0.1 maquina-0.9];
    %Para cada máquina, recorrer sus operaciones
    for oper=1:operActualMaquina(maquina)
        x = [tiemposInMaq(maquina,oper) tiemposInMaq(maquina,oper) tiemposFinMaq(maquina,oper) tiemposFinMaq(maquina,oper)];
        patch(x,y,colorT(trabMaq(maquina,oper),:));
        %etiqueta=strcat( num2str(solucion.tablasMaq.trabajo(maquina,oper)), ',', num2str(solucion.tablasMaq.operacion(maquina,oper)), ',', num2str(solucion.tablasMaq.tiempoIn(maquina,oper)), ',', num2str(solucion.tablasMaq.tiempoFin(maquina,oper)) ); 
        etiqueta=strcat( 'J', num2str(trabMaq(maquina,oper)), ',', num2str(operTrabMaq(maquina,oper)) ); 
        text(tiemposInMaq(maquina,oper),maquina-0.5,etiqueta)
    end
end
%Limite eje x
xlim([-4,makespan+5])
%Remover etiquetas en eje y y empezar eje x en 0
grafica=gca;
set(grafica,'YTick',[])
%Linea de 0 a numeroMaquinas en eje y para x en 0
x=[0,0];
y=[0,numeroMaquinas];
hold on
plot(x,y,'k','LineWidth',1.25)
hold off

end

